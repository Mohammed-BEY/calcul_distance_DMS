/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp_sig_distance_a_vol_oiseau;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

import org.controlsfx.control.Notifications;

/**
 *
 * @author Mohammed_BEY
 */
public class FXMLDocumentController implements Initializable {

    /**
     * **************************** Endroit A
     * ***************************************************************
     */
    @FXML
    TextField longitude1;
    @FXML
    TextField degreLong1;
    @FXML
    TextField minuteLong1;
    @FXML
    TextField secondeLong1;
    @FXML
    ChoiceBox longEO1;//choisir l'Est ou l'Ouest par rapport à GreenWitch

    @FXML
    TextField latitude1;
    @FXML
    TextField minuteLat1;
    @FXML
    TextField degreLat1;
    @FXML
    TextField secondeLat1;
    @FXML
    ChoiceBox latNS1;//choisir le Sud ou le Nord par raport à l'équateur
    /**
     * **************************** Endroit B
     * ***************************************************************
     */
    @FXML
    TextField longitude2;
    @FXML
    TextField degreLong2;
    @FXML
    TextField minuteLong2;
    @FXML
    TextField secondeLong2;
    @FXML
    ChoiceBox longEO2;//choisir l'Est ou l'Ouest par rapport à GreenWitch

    @FXML
    TextField latitude2;
    @FXML
    TextField minuteLat2;
    @FXML
    TextField degreLat2;
    @FXML
    TextField secondeLat2;
    @FXML
    ChoiceBox latNS2;//choisir le Sud ou le Nord par raport à l'équateur

    @FXML
    Label showdistance;//afficher la distnce entre les endroits donnés en entrée

    private boolean controleSaisie(String[] endroit1Long, String[] endroit1Lat, String[] endroit2Long, String[] endroit2Lat) {
        boolean result = false;
        //Vérification des champs de saisie
        ValuesControl verification = new ValuesControl();
        String verifLong1 = verification.verifierChampLong1(endroit1Long),
                verifLat1 = verification.verifierChampLat1(endroit1Lat),
                verifLong2 = verification.verifierChampLong2(endroit2Long),
                verifLat2 = verification.verifierChampLat2(endroit2Lat);
        if (!verifLong1.equals("")) {
            result = true;
            afficherNotif(Pos.TOP_LEFT, verifLong1);
        }
        if (!verifLat1.equals("")) {
            result = true;
            afficherNotif(Pos.BOTTOM_LEFT, verifLat1);
        }
        if (!verifLong2.equals("")) {
            result = true;
            afficherNotif(Pos.TOP_RIGHT, verifLong2);
        }
        if (!verifLat2.equals("")) {
            result = true;
            afficherNotif(Pos.BOTTOM_RIGHT, verifLat2);
        }
        return result;
    }

    //afficher une notification en montrant l'erreur
    private void afficherNotif(Pos pos, String message) {
        Notifications notificationBuilder = Notifications.create()
                .title("Erreurs détectés")
                .text(message)
                .hideAfter(Duration.seconds(5))
                .position(pos);

        notificationBuilder.showWarning();
    }

    @FXML
    void calculDistance() {
        String[] endroit1Long = coordonneeLongitude1(),
                endroit1Lat = coordonneeLatitude1(),
                endroit2Long = coordonneeLongitude2(),
                endroit2Lat = coordonneeLatitude2();
        boolean erreur;
        erreur = controleSaisie(endroit1Long, endroit1Lat, endroit2Long, endroit2Lat);
        //calcul de la distance s'il n'y a pas d'erreurs de saisie
        if (!erreur) {//il n'y a pas d'erreurs
            Distance calculDistance = new Distance();
            double distance = calculDistance.lancerCalcul(endroit1Long, endroit1Lat, endroit2Long, endroit2Lat);
            showdistance.setText(String.valueOf(distance));
        }
    }

    //Récupérer les données saisies par l'utilisateur ********************************************************/
    private String[] coordonneeLongitude1() {
        String[] result = new String[5];
        result[0] = degreLong1.getText().replaceAll(" ", "");
        result[1] = minuteLong1.getText().replaceAll(" ", "");
        result[2] = secondeLong1.getText().replaceAll(" ", "");
        result[3] = (String) longEO1.getSelectionModel().getSelectedItem();
        result[4] = longitude1.getText().replaceAll(" ", "");

        return result;
    }

    private String[] coordonneeLatitude1() {
        String[] result = new String[5];
        result[0] = degreLat1.getText().replaceAll(" ", "");
        result[1] = minuteLat1.getText().replaceAll(" ", "");
        result[2] = secondeLat1.getText().replaceAll(" ", "");
        result[3] = (String) latNS1.getSelectionModel().getSelectedItem();
        result[4] = latitude1.getText().replaceAll(" ", "");

        return result;
    }

    private String[] coordonneeLongitude2() {
        String[] result = new String[5];
        result[0] = degreLong2.getText().replaceAll(" ", "");
        result[1] = minuteLong2.getText().replaceAll(" ", "");
        result[2] = secondeLong2.getText().replaceAll(" ", "");
        result[3] = (String) longEO2.getSelectionModel().getSelectedItem();
        result[4] = longitude2.getText().replaceAll(" ", "");

        return result;
    }

    private String[] coordonneeLatitude2() {
        String[] result = new String[5];
        result[0] = degreLat2.getText().replaceAll(" ", "");
        result[1] = minuteLat2.getText().replaceAll(" ", "");
        result[2] = secondeLat2.getText().replaceAll(" ", "");
        result[3] = (String) latNS2.getSelectionModel().getSelectedItem();
        result[4] = latitude2.getText().replaceAll(" ", "");

        return result;
    }

    //in de récupération des données saisies par l'utilisateur ***********************************************/
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        latNS1.getItems().addAll("Nord", "Sud");
        latNS2.getItems().addAll("Nord", "Sud");
        longEO1.getItems().addAll("Est", "Ouest");
        longEO2.getItems().addAll("Est", "Ouest");
    }

}
