/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp_sig_distance_a_vol_oiseau;

import static java.lang.Math.abs;

/**
 *
 * @author Mohammed_BEY
 */
public class ValuesControl {

    public ValuesControl() {
    }

    public String verifierChampLong1(String[] champ) {
        String result = "";
        if (champ[0].equals("") && champ[1].equals("") && champ[2].equals("")) {
            //la longitude doit être donnée en décimal
            if (champ[4].equals("") || champ[3] == null) {
                result += "Veuillez remplir tous les champs de la longitude 1 !\n";
            } else {
                try {
                    if (abs(Double.parseDouble(champ[4])) > 180) {
                        result += "Attention! vous avez saisi une longitude non valide\n";
                    }
                } catch (NumberFormatException e) {
                    result += "Attention! vous avez saisi une longitude non valide\n";
                }
            }
        } else if (champ[0].equals("") || champ[1].equals("") || champ[2].equals("") || champ[3] == null) {
            result += "Veuillez remplir tous les champs de la longitude 1 !\n";
        } else {//Les champs sont remplis ==> contrôler ce qui a été saisi (les valeurs)
            try {
                if (abs(Double.parseDouble(champ[0])) > 180 || Double.parseDouble(champ[0]) < 0) {
                    result += "Attention! vous avez saisi un degré non valide dans la longitude 1\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! le degré donné de la longitude 1 n'est pas valide !\n";
            }

            try {
                if (abs(Double.parseDouble(champ[1])) >= 60 || Double.parseDouble(champ[1]) < 0) {
                    result += "Attention! vous avez saisi une non valide dans la longitude 1\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la minute donnée de la longitude 1 n'est pas valide !\n";
            }

            try {
                if (abs(Double.parseDouble(champ[2])) >= 60 || Double.parseDouble(champ[2]) < 0) {
                    result += "Attention! vous avez saisi une minute non valide dans la longitude 1\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la seconde donnée de la longitude 1 n'est pas valide !\n";
            }
        }
        return result;
    }

    public String verifierChampLat1(String[] champ) {
        String result = "";
        if (champ[0].equals("") && champ[1].equals("") && champ[2].equals("")) {
            //la longitude doit être donnée en décimal
            if (champ[4].equals("") || champ[3] == null) {
                result += "Veuillez remplir tous les champs de la latitude 1 !\n";
            } else {
                try {
                    if (abs(Double.parseDouble(champ[4])) > 180) {
                        result += "Attention! vous avez saisi une latitude non valide\n";
                    }
                } catch (NumberFormatException e) {
                    result += "Attention! vous avez saisi une latitude non valide\n";
                }
            }

        } else if (champ[0].equals("") || champ[1].equals("") || champ[2].equals("") || champ[3] == null) {
            result += "Veuillez remplir tous les champs de la latitude 1 !\n";
        } else {
            try {
                if (abs(Double.parseDouble(champ[0])) > 180 || Double.parseDouble(champ[0]) < 0) {
                    result += "Attention! vous avez saisi un degré non valide dans la latitude 1\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! le degré donné de la latitude 1 n'est pas valide !\n";
            }

            try {
                if (abs(Double.parseDouble(champ[1])) >= 60 || Double.parseDouble(champ[1]) < 0) {
                    result += "Attention! vous avez saisi une minute non valide dans la latitude 1\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la minute donnée de la latitude 1 n'est pas valide !\n";
            }

            try {
                if (abs(Double.parseDouble(champ[2])) >= 60 || Double.parseDouble(champ[2]) < 0) {
                    result += "Attention! vous avez saisi une seconde non valide dans la latitude 1\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la seconde donnée de la latitude 1 n'est pas valide !\n";
            }
        }
        return result;
    }

    public String verifierChampLong2(String[] champ) {
        String result = "";
        if (champ[0].equals("") && champ[1].equals("") && champ[2].equals("")) {
            //la longitude doit être donnée en décimal
            if (champ[4].equals("") || champ[3] == null) {
                result += "Veuillez remplir tous les champs de la longitude 2 !\n";
            } else {
                try {
                    if (abs(Double.parseDouble(champ[4])) > 180) {
                        result += "Attention! vous avez saisi une longitude non valide\n";
                    }
                } catch (NumberFormatException e) {
                    result += "Attention! vous avez saisi une longitude non valide\n";
                }
            }

        } else if (champ[0].equals("") || champ[1].equals("") || champ[2].equals("") || champ[3] == null) {
            result += "Veuillez remplir tous les champs de la longitude 2 !\n";
        } else {
            try {
                //c'est un nombre
                if (abs(Double.parseDouble(champ[0])) > 180 || Double.parseDouble(champ[0]) < 0) {
                    result += "Attention! vous avez saisi un degré non valide dans la longitude 2\n";
                }

            } catch (NumberFormatException e) {
                result += "Attention! le degré donné de la longitude 2 n'est pas valide !\n";
            }

            try {
                //c'est un nombre
                if (abs(Double.parseDouble(champ[1])) >= 60 || Double.parseDouble(champ[1]) < 0) {
                    result += "Attention! vous avez saisi une minute non valide dans la longitude 2\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la minute donnée de la longitude 2 n'est pas valide !\n";
            }

            try {
                //c'est un nombre
                if (abs(Double.parseDouble(champ[2])) >= 60 || Double.parseDouble(champ[2]) < 0) {
                    result += "Attention! vous avez saisi une seconde non valide dans la longitude 2\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la seconde donnée de la longitude 2 n'est pas valide !\n";
            }
        }
        return result;
    }

    public String verifierChampLat2(String[] champ) {
        String result = "";

        if (champ[0].equals("") && champ[1].equals("") && champ[2].equals("")) {
            //la longitude doit être donnée en décimal
            if (champ[4].equals("") || champ[3] == null) {
                result += "Veuillez remplir tous les champs de la latitude 2 !\n";
            } else {
                try {
                    if (abs(Double.parseDouble(champ[4])) > 180) {
                        result += "Attention! vous avez saisi une latitude non valide\n";
                    }
                } catch (NumberFormatException e) {
                    result += "Attention! vous avez saisi une latitude non valide\n";
                }
            }

        } else if (champ[0].equals("") || champ[1].equals("") || champ[2].equals("") || champ[3] == null) {
            result += "Veuillez remplir tous les champs de la latitude 2 !";
        } else {
            try {
                if (abs(Double.parseDouble(champ[0])) > 180 || Double.parseDouble(champ[0]) < 0) {
                    result += "Attention! vous avez saisi un degré non valide dans la latitude 2\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! le degré donné de la latitude 2 n'est pas valide !\n";
            }

            try {
                if (abs(Double.parseDouble(champ[1])) >= 60 || Double.parseDouble(champ[1]) < 0) {
                    result += "Attention! vous avez saisi une minute non valide dans la latitude 2\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la minute donnée de la latitude 2 n'est pas valide !\n";
            }

            try {
                if (abs(Double.parseDouble(champ[2])) >= 60 || Double.parseDouble(champ[2]) < 0) {
                    result += "Attention! vous avez saisi une seconde non valide dans la latitude 2\n";
                }
            } catch (NumberFormatException e) {
                result += "Attention! la seconde donnée de la latitude 2 n'est pas valide !\n";
            }
        }
        return result;
    }
}
