/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp_sig_distance_a_vol_oiseau;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Mohammed_BEY
 */
public class TP_SIG_Distance_A_Vol_Oiseau extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));

        Scene scene = new Scene(root, 1025, 655);
        scene.getStylesheets().add(TP_SIG_Distance_A_Vol_Oiseau.class.getResource("MiseEnForme.css").toExternalForm());
        stage.setScene(scene);
        stage.getIcons().add(new Image(TP_SIG_Distance_A_Vol_Oiseau.class.getResourceAsStream("images/images.jpg")));
        stage.setIconified(false);
        stage.setResizable(false);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
