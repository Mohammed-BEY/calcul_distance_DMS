/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp_sig_distance_a_vol_oiseau;

import static java.lang.Math.abs;

/**
 *
 * @author Mohammed_BEY
 */
public class Distance {

    float ALat, BLat, ALong, BLong;
    private int ADegreLat, BDegreLat, ADegreLong, BDegreLong, AMinuteLat, BMinuteLat, AMinuteLong, BMinuteLong;
    private double ASecondeLat, BSecondeLat, ASecondeLong, BSecondeLong, distance, rayonTerre;

    public Distance() {
    }

    //On est sûr qu'il n'y a pas d'erreurs à l'appel de cette méthode 
    //car la véréfécation a été faite dans le controlleur principal
    public double lancerCalcul(String[] longitudeA, String[] latitudeA, String[] longitudeB, String[] latitudeB) {
        rayonTerre = 6371598 / 1000;
        if (!longitudeA[0].equals("")) {
            ADegreLong = Integer.parseInt(longitudeA[0]);
            AMinuteLong = Integer.parseInt(longitudeA[1]);
            ASecondeLong = Double.parseDouble(longitudeA[2]);

            ADegreLat = Integer.parseInt(latitudeA[0]);
            AMinuteLat = Integer.parseInt(latitudeA[1]);
            ASecondeLat = Double.parseDouble(latitudeA[2]);

            BDegreLong = Integer.parseInt(longitudeB[0]);
            BMinuteLong = Integer.parseInt(longitudeB[1]);
            BSecondeLong = Double.parseDouble(longitudeB[2]);

            BDegreLat = Integer.parseInt(latitudeB[0]);
            BMinuteLat = Integer.parseInt(latitudeB[1]);
            BSecondeLat = Double.parseDouble(latitudeB[2]);

            //Convertir DMS en Décimal pour le calcul de la distance       
            //on travaille avec les coordonnées en DMS
            ALat = (float) (ADegreLat + ((ASecondeLat) / 60.0 + AMinuteLat) / 60.0);
            BLat = (float) (BDegreLat + ((BSecondeLat) / 60.0 + BMinuteLat) / 60.0);
            ALong = (float) (ADegreLong + ((ASecondeLong) / 60.0 + AMinuteLong) / 60.0);
            BLong = (float) (BDegreLong + ((BSecondeLong) / 60.0 + BMinuteLong) / 60.0);
        } else {
            ALat = (float) Double.parseDouble(latitudeB[4]);
            BLat = (float) Double.parseDouble(latitudeB[4]);
            ALong = (float) Double.parseDouble(longitudeA[4]);
            BLong = (float) Double.parseDouble(longitudeB[4]);
        }

        if (longitudeA[3].equals("Ouest")) {
            ALong = 0 - abs(ALong);
        }
        if (latitudeA[3].equals("Sud")) {
            ALat = 0 - abs(ALat);
        }
        if (longitudeB[3].equals("Ouest")) {
            BLong = 0 - abs(BLong);
        }
        if (latitudeB[3].equals("Sud")) {
            BLat = 0 - abs(BLat);
        }

        double deltaLatitide, deltaLongitude;
        deltaLatitide = BLat - ALat;
        deltaLongitude = BLong - ALong;
        float a;
        a = ((float) ((Math.sin(ALat * Math.PI / 180) * Math.sin(BLat * Math.PI / 180)) + Math.cos(ALat * Math.PI / 180) * Math.cos(BLat * Math.PI / 180) * Math.cos(deltaLongitude * Math.PI / 180)));

        distance = (float) Math.acos(a);
        distance *= rayonTerre;

        return distance;
    }
}
